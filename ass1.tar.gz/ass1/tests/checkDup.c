#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    char data[100][100];
    int i = 0;
    while(fgets(data[i],100,stdin) != NULL){
        i = i + 1;
    }
    int size = i;
    i = 0;
    while ( i <  size ){
        int j = i+1;
        while ( j < size){
           if(strcmp(data[i],data[j]) == 0){
               printf("Dup %d %d %s\n",i,j,data[i]);
           }
	   j++;
        }
        i++;
    }
    return 0;
}
