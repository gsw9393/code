#include <stdio.h>
#include <stdlib.h>

#define SIZE 6

#define TRUE 1
#define FALSE 0

int checkAdjacentSame(int numbers[SIZE], int startIndex, int length);
int checkAdjacentSequence(int numbers[SIZE], int startIndex, int length);

int total(char *buffer, int numbers[SIZE], int highestScore);
int match(char *buffer, int numbers[SIZE], int highestScore,
	      int matchSize, int scoreConstant);
int sequence(char *buffer, int numbers[SIZE], int highestScore,
	 		 int sequenceSize,
	          int scoreConstant);
int sum2(char *buffer, int numbers[SIZE], int highestScore);
int sum3(char *buffer, int numbers[SIZE], int highestScore);
int sum4(char *buffer, int numbers[SIZE], int highestScore);
int sum5(char *buffer, int numbers[SIZE], int highestScore);
int timTam(char *buffer, int numbers[SIZE], int highestScore);
void buildSequenceNumbers(char *bufferInner, int numbers[SIZE],
	                       int i, int sequenceSize);
void findOtherSum2Indexes(int i, int j, int k, int complement[3]);
void invalidInput(void);

void resetArray(int *numbers, int size);
void createFromNegative(int numbers[SIZE], int output[SIZE], int index1, int index2, int index3);

int main(void) {
	char buffer[100];
	int highestScore = 0;
	int numbers[SIZE];
	int i = 0;
	int validInput = scanf("%d %d %d %d %d %d", &numbers[0], &numbers[1],
		                   &numbers[2], &numbers[3], &numbers[4],
		                   &numbers[5]);

	if (validInput != 6) {
		invalidInput();
	}

	i = 0;
	while (i < SIZE) {
		if (numbers[i] < 0 | numbers[i] > 9) {
			invalidInput();
		}	
		i++;
	}

	i = 0;
	while (i < SIZE - 1) {
		if (numbers[i] > numbers[i + 1]) {
			invalidInput();
		}	
		i++;
	}

	// check scores
	// these have been rearranged compared to the video
	// to process them in alphabetical order to ensure that
	// equal scores later are not accepted
	highestScore = match(buffer, numbers, highestScore, 2, 19);
	highestScore = match(buffer, numbers, highestScore, 3, 21);
	highestScore = match(buffer, numbers, highestScore, 4, 23);
	highestScore = match(buffer, numbers, highestScore, 5, 25);
	highestScore = match(buffer, numbers, highestScore, 6, 27);

	highestScore = sequence(buffer, numbers, highestScore, 2, 17);
	highestScore = sequence(buffer, numbers, highestScore, 3, 18);
	highestScore = sequence(buffer, numbers, highestScore, 4, 19);
	highestScore = sequence(buffer, numbers, highestScore, 5, 20);
	highestScore = sequence(buffer, numbers, highestScore, 6, 21);
	
	highestScore = sum2(buffer, numbers, highestScore);
	highestScore = sum3(buffer, numbers, highestScore);
	highestScore = sum4(buffer, numbers, highestScore);
	highestScore = sum5(buffer, numbers, highestScore);

	highestScore = timTam(buffer, numbers, highestScore);

	highestScore = total(buffer, numbers, highestScore);
	


	// print stuff out
	printf("%s\n", buffer);

	return 0;
}

void invalidInput(void) {
	printf("Invalid input: 6 integers 1..9 in sorted order must be supplied.\n");
	exit(1);
}

//////// TOTAL ////////////////

int total(char *buffer, int numbers[SIZE], int highestScore) {
	int score = 0;
	int i = 0;
	while (i < SIZE) {
		score = score + numbers[i];
		i++;
	}
	// score is the right score
	if (score > highestScore) {
		sprintf(buffer, "Rule total - score %d.", score);
		highestScore = score;
	}
	return highestScore;
}

//////// MATCH ////////////////

int checkAdjacentSame(int numbers[SIZE], int startIndex, int length) {
	int i = startIndex;
	int returnValue = TRUE;
	while (i < startIndex + length - 1) {
		if (numbers[i] != numbers[i + 1]) {
			returnValue = FALSE;
		}
		i++;
	}
	return returnValue;
}

int match(char *buffer, int numbers[SIZE], int highestScore, int matchSize,
	       int scoreConstant) {
	int i = 0;
	int score = 0;
	int upperLimit = (matchSize - 1);
	while (i < SIZE - upperLimit) {
		if (checkAdjacentSame(numbers, i, matchSize)) {
			score = matchSize * numbers[i] + scoreConstant;
			if (score > highestScore) {
				sprintf(buffer, "Rule match-%d(%d) - score %d.", matchSize,
					     numbers[i], score);
				highestScore = score;
			}
		}
		i++;
	}
	return highestScore;
}

//////// SEQUENCE ////////////////

int checkAdjacentSequence(int numbers[SIZE], int startIndex, int length) {
	int i = startIndex;
	int returnValue = TRUE;
	while (i < startIndex + length - 1) {
		if (numbers[i] + 1 != numbers[i + 1]) {
			returnValue = FALSE;
		}
		i++;
	}
	return returnValue;
}

void buildSequenceNumbers(char *bufferInner, int numbers[SIZE], int startIndex, int sequenceSize) {
	int i = 0;
	while (i < sequenceSize) {
		bufferInner[2 * i] = numbers[startIndex + i] + 48;
		if (i == sequenceSize - 1) {
			bufferInner[2 * i + 1] = '\0';
		} else {
			bufferInner[2 * i + 1] = ',';
		}
		i++;
	}

}

int removeDuplicates(int full[SIZE], int nodups[SIZE]) {
	int fullIndex = 1;
	int nodupsIndex = 1;
	nodups[0] = full[0];
	while (fullIndex < SIZE) {
		if (full[fullIndex] != full[fullIndex - 1]) {
			nodups[nodupsIndex] = full[fullIndex];
			nodupsIndex++;
		}
		fullIndex++;
	}
	return nodupsIndex;
}

int sequence(char *buffer, int numbers[SIZE], int highestScore, int sequenceSize,
	       int scoreConstant) {
	int i = 0;
	int score = 0;
	int upperLimit = (sequenceSize - 1);
	char bufferInner[100];

	int numbersNoDups[SIZE] = {0,0,0,0,0,0};
	removeDuplicates(numbers, numbersNoDups);

	while (i < SIZE - upperLimit) {
		if (checkAdjacentSequence	(numbersNoDups, i, sequenceSize)) {
			score = sequenceSize * numbersNoDups[i + sequenceSize - 1] + scoreConstant;
			if (score > highestScore) {
				buildSequenceNumbers(bufferInner, numbersNoDups, i, sequenceSize);

				sprintf(buffer, "Rule sequence-%d(%s) - score %d.", sequenceSize,
					     bufferInner, score);
				highestScore = score;
			}
		}
		i++;
	}
	return highestScore;
}


//////// SUM ////////////////

int sum2(char *buffer, int numbers[SIZE], int highestScore) {

	int i, j, k = 0;
	int score = 0;
	i = 0;
	while (i < SIZE) { // i = index of x_a
		j = i + 1;
		while (j < SIZE) { // j = index of x_b
			k = j + 1;
			while (k < SIZE) { // k = index of x_c
				if (numbers[i] + numbers[j] == numbers[k]) {
					score = numbers[i] + numbers[k] + 22;
					if (score > highestScore) {
						sprintf(buffer, "Rule sum-2(%d+%d=%d) - score %d.",
							    numbers[i], numbers[j], numbers[k], score);
						highestScore = score;
					}
					
				}
				k++;
			}
			j++;
		}
		i++;
	}
	return highestScore;
}


void resetArray(int *numbers, int size) {
	int i = 0;
	while (i < size) {
		numbers[i] = 0;
		i++;
	}
}

void createFromNegative(int numbers[SIZE], int output[SIZE], int index1, int index2, int index3) {
	resetArray(output, SIZE);
	int i = 0;
	int o = 0;
	while (i < SIZE) {
		if (i != index1 && i != index2 && i != index3) {
			output[o] = numbers[i];
			o++;
		}
		i++;
	}
}

int sum3(char *buffer, int numbers[SIZE], int highestScore) {
	int subArray[SIZE] = {0,0,0,0,0,0};
	int i, j, score;
	i = 0;
	while (i < SIZE) {
		j = i + 1;
		while (j < SIZE) {
			createFromNegative(numbers, subArray, i, j, -1);
			if (subArray[0] + subArray[1] + subArray[2] == subArray[3]) {
				score = subArray[0] + subArray[3] + 29;
				if (score > highestScore) {
					sprintf(buffer, "Rule sum-3(%d+%d+%d=%d) - score %d.",
						    subArray[0], subArray[1], subArray[2],
						    subArray[3], score);
					highestScore = score;
				}
				
			}
			j++;
		}
		i++;
	}
	return highestScore;
}

int sum4(char *buffer, int numbers[SIZE], int highestScore) {
	int subArray[SIZE];
	int i, score;
	i = 0;
	while (i < SIZE) {
		createFromNegative(numbers, subArray, i, -1, -1);
		if (subArray[0] + subArray[1] + subArray[2] + subArray[3] ==
			 subArray[4]) {
			score = subArray[0] + subArray[4] + 38;
			if (score > highestScore) {
				sprintf(buffer, "Rule sum-4(%d+%d+%d+%d=%d) - score %d.",
					    subArray[0], subArray[1], subArray[2],
					    subArray[3], subArray[4], score);
				highestScore = score;
			}
		}
		i++;
	}
	return highestScore;
}

int sum5(char *buffer, int numbers[SIZE], int highestScore) {
	int score = 0;
	int sum = 0;
	int i = 0;
	while (i < SIZE - 1) {
		sum = sum + numbers[i];
		i++;
	}
	if (sum == numbers[5]) {
		score = numbers[0] + numbers[5] + 49;
		if (score > highestScore) {
			sprintf(buffer, "Rule sum-5(%d+%d+%d+%d+%d=%d) - score %d.",
							 numbers[0], numbers[1], numbers[2], numbers[3],
							 numbers[4], numbers[5], score);
			highestScore = score;
		}
	}
	return highestScore;
}






/////////// TIM TAM

void findOtherSum2Indexes(int i, int j, int k, int complement[3]) {
	int complementCounter = 0;
	int x = 0;
	while (x < SIZE) {
		if (x != i && x != j && x != k) {
			complement[complementCounter] = x;
			complementCounter++;
		}
		x++;
	}
}


int timTam(char *buffer, int numbers[SIZE], int highestScore) {
	int i, j, k = 0;
	int score = 0;
	int other[SIZE] = {0,0,0,0,0,0};

	i = 0;
	while (i < SIZE) { // i = index of x_a
		j = i + 1;
		while (j < SIZE) { // j = index of x_b
			k = j + 1;
			while (k < SIZE) { // k = index of x_c
				if (numbers[i] + numbers[j] == numbers[k]) {
					createFromNegative(numbers, other, i, j, k);
					
					if (other[0] + other[1] == other[2]) {
						score = numbers[i] + 2 * numbers[j] + 3 * numbers[k] + 
						        4 * other[0] + 5 * other[1] + 
						        6 * other[2];
						if (score > highestScore) {
							sprintf(buffer, "Rule tim-tam(%d+%d=%d,%d+%d=%d) - score %d.",
								    numbers[i], numbers[j], numbers[k],
								    other[0], other[1],
								    other[2],
								    score);
							highestScore = score;
						}
					}
					
					
				}
				k++;
			}
			j++;
		}
		i++;
	}
	return highestScore;
}
